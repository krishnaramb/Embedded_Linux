/*
Name: Krishna Ram Budhathoki
email: krishna.budhathoki@gmail.com
        File: monitor.c

    A Posix thread to monitor console input for parameter changes
    Also includes functions to create and terminate the thread called
    from main() in the thermostat.c file

*/
#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <string.h>
#include <unistd.h>
#include <signal.h>
#include <pthread.h>

#include "thermostat.h"

#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>


const char *delims = " \t,=";

#define BUFLEN 80

pthread_mutex_t paramMutex;
pthread_t monitorT;
//unsigned int curtemp =540; //initialization
void createServer(int *server_socket,int *client_socket){
	  	int client_len;
	    struct sockaddr_in server_addr, client_addr;
	    //char text[80];
	    int  result;

	// Create unnamed socket and give it a "name"
	    *server_socket = socket (PF_INET, SOCK_STREAM, 0);
	    server_addr.sin_family = AF_INET;
	    result = inet_aton (SERVER, &server_addr.sin_addr);
	    if (result == 0)
	    {
	        printf ("inet_aton failed\n");
	        exit (1);
	    }
	    server_addr.sin_port = htons (PORT);

	// Bind to the socket
	    result = bind (*server_socket, (struct sockaddr *) &server_addr, sizeof (server_addr));
	    if (result != 0)
	    {
	        perror ("bind");
	        exit (1);
	    }

	// Create a client queue
	    result = listen (*server_socket, 1);
	    if (result != 0)
	    {
	        perror ("listen");
	        exit (1);
	    }
	    printf ("Network server running\n");

	// Accept a connection
	    client_len = sizeof (client_addr);
	    *client_socket = accept (*server_socket, (struct sockaddr *) &client_addr, (socklen_t * __restrict__)&client_len);

	    printf ("Connection established to %s\n", inet_ntoa (client_addr.sin_addr));
	   // return client_socket;

}

void *monitor (void *arg)
{
    char text[BUFLEN], *cmd,*charerror="wrong values entered. pls try again \n" ;
    int server_socket, client_socket;
    unsigned int stop = 0;
    unsigned int value,len;
    char OK[] = "OK";
    char currtmp[10];

    createServer(&server_socket,&client_socket);
    if (client_socket < 0){ //if result is -ve, return fail
    	printf("unable to create connection");
    	exit(1);

    }
   // printf("Krishnarab: %d\n",curtemp);
   while(1)
    {
    	printf("waiting for the client cmd \n");
    	len = read (client_socket, text, sizeof (text));

        //read(text, BUFLEN, stdin);
    	//printf("text found is %s\n",text);

    	cmd = strtok (text, delims);



        while (cmd)
        {
            //value = atoi (strtok (NULL, delims));


            pthread_mutex_lock (&paramMutex);   //get exclusive access to parameters 
            switch (*cmd)
            {
                case 's':
                	value = atoi (strtok (NULL, delims));
                    setpoint = value;
                    write (client_socket, OK, sizeof(OK));
                    break;
                case 'l':
                	value = atoi (strtok (NULL, delims));
                    limit = value;
                    write (client_socket, OK, sizeof(OK));
                    break;
                case 'd':
                	value = atoi (strtok (NULL, delims));
                    deadband = value;
                    write (client_socket, OK, sizeof(OK));
                    break;

                case '?':

                	sprintf(currtmp,"%d",curtemp); //converting interger to character
                	write(client_socket,currtmp,strlen(currtmp));
                	break;

                case 'q':

                	printf ("Connection terminated.  Server shutting down\n");
                	stop =1;
                	break;

                default:

                	printf("wrong values entered. pls try again \n");
                	write(client_socket,charerror,strlen(charerror));
                    break;
            }
            if (stop){
            	close (client_socket);
            	//close (server_socket);
            	pthread_mutex_unlock (&paramMutex);
            	return NULL;

            }
            pthread_mutex_unlock (&paramMutex);     // release the parameters
            
            cmd = strtok (NULL, delims);

        }
    }
    return NULL;
}

#define CHECK_ERROR if (error) { \
        printf ("%s\n", strerror (error)); \
        return 1; }

int createThread ()
/*
    Creates the mutex and starts up the monitor thread
*/
{
    int error;
/*
    Create the Posix objects
*/
    error = pthread_mutex_init (&paramMutex, NULL);
    CHECK_ERROR;
    
    error = pthread_create (&monitorT, NULL, monitor, NULL);
    CHECK_ERROR;
    
    return 0;
}

void terminateThread (void)
/*
    Cancel and join the monitor thread
*/
{
	void *thread_val;
	
    pthread_cancel (monitorT);
    pthread_join (monitorT, &thread_val);
}
