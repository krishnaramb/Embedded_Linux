/*
        Blocking character device driver
        
    Copyright (C) 2007 to 2016 Doug Abbott
    
    This source code file is derived from source code written
    by Alesandro Rubini and Jonathan Corbett for the book "Linux
    Device Drivers" published by O'Reilly & Associates.  It may
    be freely used, adapted, and redistributed in source or
    binary form, provided the original sources and current
    author are acknowledged.
    
    No warranty is expressed or implied, nor is any responsibility
    assumed for errors or for fitness for any purpose.
    
    1/25/12	DLA		Replaced semaphore with mutex
    6/5/13  DLA     Added device class
    5/12/16 DLA     Replaced create_proc_entry() (Deprecated in kernel 3.10)
                    with proc_create()
*/

#include <linux/module.h>

#include <linux/kernel.h>	/* printk(), min() */
#include <linux/slab.h>		/* kmalloc() */
#include <linux/fs.h>		/* everything... */
#include <linux/proc_fs.h>
#include <linux/errno.h>	/* error codes */
#include <linux/types.h>	/* size_t */
#include <linux/fcntl.h>
#include <linux/poll.h>
#include <linux/seq_file.h>
#include <linux/cdev.h>
#include <linux/device.h>
#include <linux/sched.h>
#include <asm/uaccess.h>
#include <linux/mutex.h>

#ifdef DEBUG
#   define PDEBUG(fmt, args...) printk( KERN_WARNING "pipe: " fmt, ## args)
#else
#   define PDEBUG(fmt, args...) /* not debugging: nothing */
#endif
/*
 * Module parameters can be set at comple time or load time.
 */
int major =   0;
int minor =   0;
int nr_devs = 4;  /* number of devices */
unsigned int data_size = 4; /* kbytes */
int flg =1;
module_param (major, int, S_IRUGO);
module_param (minor, int, S_IRUGO);
module_param (nr_devs, int, S_IRUGO);
module_param (data_size, uint, S_IRUGO);

MODULE_AUTHOR("Doug Abbott");
MODULE_LICENSE("GPL");

struct pipe_dev_t {
        wait_queue_head_t inq, outq;       /* read and write queues */
        char *buffer, *end;                /* begin of buf, end of buf */
        int buffersize;                    /* used in pointer arithmetic */
        char *rp, *wp;                     /* where to read, where to write */
        int nreaders, nwriters;            /* number of openings for r/w */
        struct fasync_struct *async_queue; /* asynchronous readers */
        struct mutex m;              	   /* mutual exclusion */
        struct cdev cdev;                  /* Char device structure */
        int *wflag;
} *pipe_devices;


//struct pipe_dev_t *dev= NULL;


struct class *pipe_class;

#ifdef DEBUG
/*
 * Here are our sequence iteration methods for the seq_file interface.
 * Our "position" is simply the device number.
 */
static void *pipe_seq_start (struct seq_file *s, loff_t *pos)
{
    if (*pos >= nr_devs)
        return NULL;   /* No more to read */
    return pipe_devices + *pos;
}

static void *pipe_seq_next (struct seq_file *s, void *v, loff_t *pos)
{
    (*pos)++;
    if (*pos >= nr_devs)
        return NULL;
    return pipe_devices + *pos;
}

static void pipe_seq_stop (struct seq_file *s, void *v)
{
    /* Actually, there's nothing to do here */
}

static int pipe_seq_show (struct seq_file *s, void *v)
{
    struct pipe_dev_t *dev = (struct pipe_dev_t *) v;

    if (mutex_lock_interruptible (&dev->m))
        return -ERESTARTSYS;
    seq_printf (s, "Device %i: buffer = %p, rp = %p, wp = %p\n", (int) (dev - pipe_devices), dev->buffer, dev->rp, dev->wp);
    seq_printf (s, "    n_readers = %d, n_writers = %d\n", dev->nreaders, dev->nwriters);

    mutex_unlock (&dev->m);
    return 0;
}
/*
 * Sequence operations structure
 */
static struct seq_operations pipe_seq_ops = {
    .start = pipe_seq_start,
    .next  = pipe_seq_next,
    .stop  = pipe_seq_stop,
    .show  = pipe_seq_show
};
/*
 * Now to implement the /proc file we need only make an open
 * method which sets up the sequence operators.
 */
static int proc_open (struct inode *inode, struct file *file)
{
    return seq_open (file, &pipe_seq_ops);
}
/*
 * Create a set of file operations for our proc file.
 */
static struct file_operations pipe_proc_ops = {
    .owner   = THIS_MODULE,
    .open    = proc_open,
    .read    = seq_read,
    .llseek  = seq_lseek,
    .release = seq_release
};
#endif  /* DEBUG */

static int pipe_fasync (int fd, struct file *filp, int mode);
/*
 * Open and close
 */
static int pipe_open (struct inode *inode, struct file *filp)
{
	struct pipe_dev_t *dev;
	//PDEBUG("before: address of dev: %p \n",dev);

	dev = container_of (inode->i_cdev, struct pipe_dev_t, cdev);

//	if (!dev->flag){ //flag is null for the first time
//		PDEBUG("THIS PRINT should come only once when any process opens up the pipe for the first time\n");
	//	dev->flag=&flg;

//	}

	PDEBUG("address pointed by dev: %p \n",dev);
	//PDEBUG("filps f_pos: %p\n",filp->f_pos);
	PDEBUG("filp: %p\n",filp);
	filp->private_data = dev;

	if (mutex_lock_interruptible (&dev->m))
		return -ERESTARTSYS;
        
	if (!dev->buffer)
    {   /* allocate the buffer */
		PDEBUG("buffer check \n");
		dev->buffer = kmalloc (data_size*1024, GFP_KERNEL);
		if (!dev->buffer)
        {
			mutex_unlock (&dev->m);
			return -ENOMEM;
		}
    }
   // dev->buffersize = data_size*1024;

   // dev->end = dev->buffer + dev->buffersize;
    //dev->rp = dev->wp = dev->buffer; /* read and write from the beginning */

/* ReInitialize the variables in the data structure only when both nreaders and nwriters become 0 */
  if (dev->nreaders==0 && dev->nwriters==0 && !dev->wflag){
	  PDEBUG("nreaders and nwriters are both zeros, re-initializing data structure: Called by \"%s\"\n",current->comm );
	  dev->buffersize = data_size*1024;
	  dev->end = dev->buffer + dev->buffersize;
	  dev->rp = dev->wp = dev->buffer; /* read and write from the beginning */
    }

	/* use f_mode, not f_flags: it's cleaner (fs/open.c tells why) */
	if (filp->f_mode & FMODE_READ)
		dev->nreaders++;
	if (filp->f_mode & FMODE_WRITE){
		dev->nwriters++;
		if (dev->nreaders ==0)
			dev->wflag=&flg;

	}
	mutex_unlock (&dev->m);
	PDEBUG ("open called by %s.  nreaders = %i, nwriters = %i\n", current->comm, dev->nreaders, dev->nwriters);

	return nonseekable_open (inode, filp);
}

static int pipe_release (struct inode *inode, struct file *filp)
{
    struct pipe_dev_t *dev = filp->private_data;

    /* remove this filp from the asynchronously notified filp's */
    pipe_fasync (-1, filp, 0);
    
    mutex_lock (&dev->m);
    if (filp->f_mode & FMODE_READ)
        dev->nreaders--;
    if (filp->f_mode & FMODE_WRITE)
        dev->nwriters--;
    PDEBUG("wflag: %p, nreaders: %d nwriters: %d\n",dev->wflag,dev->nreaders,dev->nwriters);
    if (dev->nreaders + dev->nwriters == 0 && !dev->wflag)
    {
    	PDEBUG("PIPE memroy clean up is called\n");
    	kfree (dev->buffer);
        dev->buffer = NULL; /* the other fields are not checked on open */
    }
    PDEBUG ("release called by %s\n", current->comm);
    PDEBUG ("dev buffer pointer after release: %p\n",dev->buffer);
    mutex_unlock (&dev->m);
    return 0;
}
/*
 * Data management: read and write
 */

static ssize_t pipe_read (struct file *filp, char __user *buf, size_t count,
                loff_t *f_pos)
{
    struct pipe_dev_t *dev = filp->private_data;

    if (mutex_lock_interruptible (&dev->m))
        return -ERESTARTSYS;

    while (dev->rp == dev->wp)
    { /* nothing to read */
        mutex_unlock (&dev->m); /* release the lock */
        if (filp->f_flags & O_NONBLOCK)
            return -EAGAIN;
            
        PDEBUG ("\"%s\" reading: going to sleep\n", current->comm);
        PDEBUG ("    wp: %p, rp: %p\n", dev->wp, dev->rp);
        if (wait_event_interruptible (dev->inq, (dev->rp != dev->wp)))
            return -ERESTARTSYS; /* signal: tell the fs layer to handle it */
        /* otherwise loop, but first reacquire the lock */
        if (mutex_lock_interruptible (&dev->m))
            return -ERESTARTSYS;
        PDEBUG ("reading woke up.  wp: %p, rp %p\n", dev->wp, dev->rp);

    }
    /* ok, data is there, return something */
    if (dev->wp > dev->rp)
        count = min (count, (size_t)(dev->wp - dev->rp));
    else /* the write pointer has wrapped, return data up to dev->end */
        count = min (count, (size_t)(dev->end - dev->rp));
        
    if (copy_to_user (buf, dev->rp, count))
    {
        mutex_unlock (&dev->m);
        return -EFAULT;
    }

    dev->wflag =NULL; //after reading setting the wflag to NULL so we can release memroy later
    PDEBUG("settng back the wflag to %p",dev->wflag);
    dev->rp += count;
    if (dev->rp == dev->end)
        dev->rp = dev->buffer; /* wrapped */
    mutex_unlock (&dev->m);

    /* finally, awake any writers and return */
    wake_up_interruptible (&dev->outq);
    PDEBUG ("\"%s\" read %li bytes\n",current->comm, (long)count);
    return count;
}

static int spacefree (struct pipe_dev_t *dev)
/* How much space is free? */
{
    if (dev->rp == dev->wp)
        return dev->buffersize - 1;
    return ((dev->rp + dev->buffersize - dev->wp) % dev->buffersize) - 1;
}

static int pipe_getwritespace (struct pipe_dev_t *dev, struct file *filp)
/*
   Wait for space for writing; caller must hold device mutex.  On
   error the mutex will be released before returning.
*/
{
    while (spacefree (dev) == 0)
    { /* full */
        DEFINE_WAIT(wait);
        
        mutex_unlock (&dev->m);
        if (filp->f_flags & O_NONBLOCK)
            return -EAGAIN;
            
        PDEBUG ("\"%s\" writing: going to sleep\n",current->comm);
        prepare_to_wait (&dev->outq, &wait, TASK_INTERRUPTIBLE);
        if (spacefree (dev) == 0)
            schedule();
            
        finish_wait (&dev->outq, &wait);
        if (signal_pending (current))
            return -ERESTARTSYS; /* signal: tell the fs layer to handle it */
            
        if (mutex_lock_interruptible (&dev->m))
            return -ERESTARTSYS;
    }
    return 0;
}

static ssize_t pipe_write (struct file *filp, const char __user *buf, size_t
count, loff_t *f_pos)
{
    struct pipe_dev_t *dev = filp->private_data;
    int result;

    if (mutex_lock_interruptible(&dev->m))
        return -ERESTARTSYS;

    /* Make sure there's space to write */
    result = pipe_getwritespace (dev, filp);
    if (result)
        return result; /* pipe_getwritespace called up(&dev->m) */

    /* ok, space is there, accept something */
    count = min (count, (size_t)spacefree (dev));
    if (dev->wp >= dev->rp)
        count = min (count, (size_t)(dev->end - dev->wp)); /* to end-of-buf */
    else /* the write pointer has wrapped, fill up to rp-1 */
        count = min (count, (size_t)(dev->rp - dev->wp - 1));
    if (copy_from_user (dev->wp, buf, count))
    {
        mutex_unlock (&dev->m);
        return -EFAULT;
    }
    PDEBUG ("writing woke up.  wp: %p, rp %p, count %i\n", dev->wp, dev->rp, 
        (int) count);
    dev->wp += count;
    if (dev->wp == dev->end)
        dev->wp = dev->buffer; /* wrapped */
    mutex_unlock (&dev->m);

    PDEBUG ("\"%s\" wrote %li bytes.  wp: %p, rp: %p\n",current->comm, (long)count, dev->wp, dev->rp);
    /* finally, awake any reader */
    wake_up_interruptible (&dev->inq);  /* blocked in read() and select() */

    /* and signal asynchronous readers, explained late in chapter 5 */
    if (dev->async_queue)
    {
        PDEBUG ("sending async notification\n");
        kill_fasync (&dev->async_queue, SIGIO, POLL_IN);
    }
    return count;
}

static unsigned int pipe_poll (struct file *filp, poll_table *wait)
{
    struct pipe_dev_t *dev = filp->private_data;
    unsigned int mask = 0;
/*
     The buffer is circular; it is considered full if "wp" is right behind "rp"
     and empty if the two are equal.
*/
    mutex_lock (&dev->m);
    poll_wait (filp, &dev->inq,  wait);
    poll_wait (filp, &dev->outq, wait);
    
    if (dev->rp != dev->wp)
        mask |= POLLIN | POLLRDNORM;    /* readable */
    if (spacefree (dev))
        mask |= POLLOUT | POLLWRNORM;   /* writable */
    mutex_unlock (&dev->m);
    return mask;
}

static int pipe_fasync (int fd, struct file *filp, int mode)
{
    struct pipe_dev_t *dev = filp->private_data;

    PDEBUG ("%s called fasync: mode = %d, fd = %d\n", current->comm, mode, fd);
    return fasync_helper( fd, filp, mode, &dev->async_queue);
}
/*
    File Operations Table
*/
struct file_operations pipe_fops = {
    .owner =    THIS_MODULE,
    .llseek =   no_llseek,
    .read =     pipe_read,
    .write =    pipe_write,
    .poll =     pipe_poll,
    .open =     pipe_open,
    .release =  pipe_release,
    .fasync =   pipe_fasync,
};
/*
 * Finally, the module stuff
 */

void pipe_cleanup (void)
/*
  This is called when the module terminates or on failure.
  It is required to never fail, even if nothing was initialized first
*/
{
    int i;
    dev_t devno = MKDEV(major, minor);

#ifdef DEBUG
    remove_proc_entry ("pipeseq", NULL);    /* changed */
#endif

    if (!pipe_devices)
        return; /* nothing else to release */

    for (i = 0; i < nr_devs; i++)
    {
        cdev_del (&pipe_devices[i].cdev);
        kfree (pipe_devices[i].buffer);
        device_destroy (pipe_class, MKDEV(major, minor + i));
    }
    kfree (pipe_devices);
    unregister_chrdev_region (devno, nr_devs);
    pipe_devices = NULL; /* pedantic */
    class_destroy (pipe_class);
}

#define DEVICE_NAME "blocking"

struct proc_dir_entry *pipe_proc;

int pipe_init (void)
/*
  Initialize the pipe devs.
 */
{
    int i, result;
    dev_t dev = 0;

/*
  Get a range of minor numbers to work with, asking for a dynamic
  major unless directed otherwise at load time.
*/
    if (major)
    {
        dev = MKDEV(major, minor);
        result = register_chrdev_region (dev, nr_devs, DEVICE_NAME);
    }
    else
    {
        result = alloc_chrdev_region (&dev, minor, nr_devs, DEVICE_NAME);
        major = MAJOR(dev);
    }
    if (result < 0)
    {
        printk (KERN_WARNING "blocking: can't get major %d\n", major);
        return result;
    }
// Populate sysfs entries
    pipe_class = class_create (THIS_MODULE, DEVICE_NAME);

    pipe_devices = kmalloc (nr_devs*sizeof (struct pipe_dev_t), GFP_KERNEL);
    if (pipe_devices == NULL)
    {
        unregister_chrdev_region (dev, nr_devs);
        return -ENOMEM;
    }
    memset (pipe_devices, 0, nr_devs*sizeof (struct pipe_dev_t));
    for (i = 0; i < nr_devs; i++)
    {
        int err;
        
        init_waitqueue_head (&(pipe_devices[i].inq));
        init_waitqueue_head (&(pipe_devices[i].outq));
        mutex_init (&pipe_devices[i].m);
        
        cdev_init (&pipe_devices[i].cdev, &pipe_fops);
        pipe_devices[i].cdev.owner = THIS_MODULE;
        err = cdev_add (&pipe_devices[i].cdev, MKDEV(major, minor + i), 1);
/* Fail gracefully if need be */
        if (err)
            printk(KERN_NOTICE "Error %d adding blocking_char%d", err, i);
// Create /dev node
        device_create (pipe_class, NULL, MKDEV (major, minor + i), NULL, "pipe%d", i);
    }
#ifdef DEBUG
/* Add proc file using seq file system */
    proc_create ("pipeseq", 0 /* default access mode */,
             NULL /* parent dir */, &pipe_proc_ops); 
#endif
    return 0;
}

module_init(pipe_init);
module_exit(pipe_cleanup);
