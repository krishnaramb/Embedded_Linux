/*
Name: Krishna Ram Budhathoki
email: krishna.budhathoki@gmail.com
        File: measure.c

    A simple data acquisition program that reads ADC channel 0
    and sends it to stdout.  Reads the pushbuttons and writes
    the button number to the LEDs.
*/

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <signal.h>

#include "driver.h"
#include <pthread.h>
#include "thermostat.h"
#include "lcdutils.h"
#include <errno.h>

#define FATAL do { fprintf(stderr, "Error at line %d, file %s (%d) [%s]\n", \
  __LINE__, __FILE__, errno, strerror(errno)); exit(1); } while(0)


#define START_POS 10
#define ROW_DELTA 10
#define COL_DELTA 20

extern int errno;

int running = 1;

unsigned int setpoint =50;
unsigned int limit =53;
unsigned int deadband =1;
unsigned int curtemp =54;

int init_screen(void);
void write_screen(void);
//int value; //global
void done (int sig)
/*
    Signal handler to stop the program gracefully
*/
{
    running = 0;
}

int main (int argc, char *argv[])
{

	if(init_screen() == -1){
		FATAL;
		}
	int monitor_thread_result = createThread();
	if (monitor_thread_result > 0){
		printf("could not create the monitor thread\n");
		exit(1);

	}


    typedef enum name{HIGH,LIMIT,OK}state;
    //state state_t = OK;
	int alarm_flag,cooler_flag;
	state  current_state = OK; //initialization


    unsigned int wait,wait_b,loop=0;
    //unsigned int  i;



    signal (SIGINT, done);  // set up signal handler
    if (argc > 1)           // get wait time
        sscanf (argv[1], "%d", &wait);
    else
        wait = 2;

    if (initDigIO() < 0)
    {
        printf ("Couldn't initialize digital I/O\n");
        exit (1);
    }
    if (initAD() < 0)
    {
        printf ("Couldn't initialize A/D converter\n");
        exit (2);
    }

    //clear ALARM bit and COOLER bit
    alarm_flag=0;
    cooler_flag=0;
    
    clearDigOut(COOLER);
    clearDigOut(ALARM);



    //take the first reading before going to the loop
    curtemp = readAD (0);
    curtemp /=10;
    wait_b =wait;  //save the value of wait in wait_b
    while (running)
    {
    	
        sleep (1);
        wait--;
        if (wait ==0){
        	curtemp = readAD (0);
        	curtemp /=10;
             wait = wait_b; //restore the wait value
             printf ("Sample %d = %d\n", loop, curtemp);
             loop++;

            pthread_mutex_lock (&paramMutex);
            switch(current_state ){  // running into the statemachine only once when we have temperature reading

            	case OK: //both the cooler and alarm flag are OFF here


                     if (curtemp > limit){
                            current_state = LIMIT;
                            alarm_flag =1;
                            cooler_flag =1;

                      }else if (curtemp > setpoint + deadband){
                            current_state = HIGH;
                            cooler_flag=1;
                            
                        }
                        
                        break;


            	case HIGH: //only cooler flag is ON here
            		if (curtemp > limit){

                        alarm_flag =1;
                        current_state = LIMIT;
                        

            		}
            		else if (curtemp <  setpoint - deadband){
                      cooler_flag =0;
                      current_state = OK;
            		}
            		break;

            	case LIMIT: //both cooler and alarm flags are ON here

                    if (curtemp < setpoint-deadband){
                        current_state =OK;
                        cooler_flag = 0;
                        alarm_flag =0;

                    }else if (curtemp < limit){
                        alarm_flag = 0;
                        current_state = HIGH;

                    }

            		break;


            } //end of switch
            pthread_mutex_unlock (&paramMutex);
            if (cooler_flag)
                 setDigOut (COOLER);
             else
                 clearDigOut (COOLER);


        } //end of wait if condition

        //adding handle for alarm for LIMIT



        if(current_state == LIMIT){  //toggle the alarm if state is LIMIT
            if (alarm_flag == 1){
                setDigOut (ALARM);
                alarm_flag =0;

            }else{
                clearDigOut (ALARM);
                alarm_flag =1;
            }
                

        }else{ //its needed to reset the alarm if state changed from LIMIT to other state during ALARM was on
            clearDigOut (ALARM);
        }
        write_screen();
        
    } //end of while loop

    writeDigOut (0);		// turn off the LEDs
    printf ("Goodbye\n");
    closeAD();
    closeDigIO();
    terminateThread();
    return 0;
}

int init_screen(void){
	int L_result;
	unsigned int row, col, width,i;
	char *words[] = {"Temp","Setpoint","Limit","Deadband"};
	row = START_POS;
	col = START_POS;
	width = 10;
	L_result = LCD_init();
	if (L_result == -1){
		return L_result;
	}
	for (i= 0;i< 4;i++){
		if (i < 2){
			row = START_POS;
		}else{
			row = START_POS+ROW_DELTA;
		}
		if (i == 1||i==3){
			col =START_POS+COL_DELTA;
		}else{
			col =START_POS;
		}

		LCD_write_string (row, col, words[i]);
	}

	return L_result;
}

void write_screen(void){
	//sleep(5);
	unsigned int row, col,delta,i;
	int thermo_val[] ={curtemp,setpoint,limit,deadband};
	//int thermo_val[] ={100,20,30,40};
	//row = START_POS+10;
	//col = START_POS+10;
	delta = 2;

	unsigned int width[]={3,5,4,5};

	for (i= 0;i< 4;i++){
		if (i < 2){
			row = START_POS+delta;
		}else{
			row = START_POS+ROW_DELTA+delta;
		}
		if (i == 1||i==3){
			col =START_POS+COL_DELTA;
		}else{
			col =START_POS;
		}

		LCD_write_number (row, col,thermo_val[i],width[i]);
		//LCD_write_string (row, col,"aa");
	}

}
